#!/bin/bash
# generate files with random sizes
date
for i in $(seq 1 5); do
  random_size=$((RANDOM % 1000 + 1)) # Random size between 1 and 1000 bytes
  dd if=/dev/urandom of=$i.txt bs=1 count=$random_size
  echo "Generated $i.txt with $random_size bytes"
  sleep 1
done
date
